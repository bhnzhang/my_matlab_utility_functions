/* Here's a simple Hello World program in C++, which won't
 * do much, but does show syntax highlighting.
 */
#include <iostream>

void some_complex_work();

int main()
{
    if (2+2==5)
    {
        // This happens very often indeed
        std::cout << "Hello World!";
    }
    else
    {
        @ // bad character makes an error
        character = 'a';
        len = strlen("foobar");
        return len;
    }
}
